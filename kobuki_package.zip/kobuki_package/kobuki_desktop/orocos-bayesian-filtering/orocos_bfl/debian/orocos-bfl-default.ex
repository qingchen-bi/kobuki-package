# Defaults for orocos-bfl initscript
# sourced by /etc/init.d/orocos-bfl
# installed at /etc/default/orocos-bfl by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
